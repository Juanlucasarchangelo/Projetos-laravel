<div class="topo">

    <div class="logo">
        <img src="<?php echo e(asset('img/logo.png')); ?>">
    </div>

    <div class="menu">
        <ul>
            <li><a href="<?php echo e(route('site.index')); ?>">Principal</a></li>
            <li><a href="<?php echo e(route('site.sobrenos')); ?>">Sobre Nós</a></li>
            <li><a href="<?php echo e(route('site.contato')); ?>">Contato</a></li>
        </ul>
    </div>
</div><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/site/layouts/_partials/topo.blade.php ENDPATH**/ ?>