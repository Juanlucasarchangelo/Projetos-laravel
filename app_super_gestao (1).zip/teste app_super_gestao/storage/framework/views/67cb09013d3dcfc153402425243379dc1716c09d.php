<?php $__env->startSection('titulo', 'Fornecedor'); ?>

<?php $__env->startSection('conteudo'); ?>
    <br><br><br><br>Fornecedor
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app.layouts.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/app/fornecedor.blade.php ENDPATH**/ ?>