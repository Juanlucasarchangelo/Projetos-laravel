P1 = <?php echo e($xyz); ?>

<br />
P2 = <?php echo e($zzz); ?><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/site/teste.blade.php ENDPATH**/ ?>