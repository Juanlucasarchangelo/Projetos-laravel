P1 = {{ $xyz }}
<br />
P2 = {{ $zzz }}