@extends('app.layouts.basico')

@section('titulo', 'Home')

@section('conteudo')
    <br><br><br><br>Home
@endsection

