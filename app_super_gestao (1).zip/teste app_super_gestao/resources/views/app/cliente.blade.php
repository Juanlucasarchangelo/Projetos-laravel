@extends('app.layouts.basico')

@section('titulo', 'Cliente')

@section('conteudo')
    <br><br><br><br>Cliente
@endsection

