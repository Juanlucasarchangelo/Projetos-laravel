@extends('app.layouts.basico')

@section('titulo', 'Produto')

@section('conteudo')
    <br><br><br><br>Produto
@endsection

