<?php $__env->startSection('titulo', 'Produto'); ?>

<?php $__env->startSection('conteudo'); ?>
    
    <div class="conteudo-pagina">

        <div class="titulo-pagina-2">
            <p>Editar Produto</p>
        </div>

        <div class="menu">
            <ul>
                <li><a href="<?php echo e(route('produto.index')); ?>">Voltar</a></li>
                <li><a href="">Consulta</a></li>
            </ul>
        </div>

        <div class="informacao-pagina">
            <div style="width: 30%; margin-left: auto; margin-right: auto;">
                <?php $__env->startComponent('app.produto._components.form_create_edit', ['produto' => $produto, 'unidades' => $unidades, 'fornecedores' => $fornecedores]); ?>
                <?php if (isset($__componentOriginald519af9fb043221d8955b6a1b2d2bbe4a651d589)): ?>
<?php $component = $__componentOriginald519af9fb043221d8955b6a1b2d2bbe4a651d589; ?>
<?php unset($__componentOriginald519af9fb043221d8955b6a1b2d2bbe4a651d589); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app.layouts.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/app/produto/edit.blade.php ENDPATH**/ ?>