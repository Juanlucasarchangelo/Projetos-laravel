<?php $__env->startSection('titulo', 'Pedido'); ?>

<?php $__env->startSection('conteudo'); ?>
    
    <div class="conteudo-pagina">

        <div class="titulo-pagina-2">
            <p>Adicionar Pedido</p>
        </div>

        <div class="menu">
            <ul>
                <li><a href="<?php echo e(route('pedido.index')); ?>">Voltar</a></li>
                <li><a href="">Consulta</a></li>
            </ul>
        </div>

        <div class="informacao-pagina">
            <div style="width: 30%; margin-left: auto; margin-right: auto;">
                <?php $__env->startComponent('app.pedido._components.form_create_edit', ['clientes' => $clientes]); ?>
                <?php if (isset($__componentOriginalbcc592268655e3bf3f28b58d836ffc7209ba1b2d)): ?>
<?php $component = $__componentOriginalbcc592268655e3bf3f28b58d836ffc7209ba1b2d; ?>
<?php unset($__componentOriginalbcc592268655e3bf3f28b58d836ffc7209ba1b2d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>             
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app.layouts.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/app/pedido/create.blade.php ENDPATH**/ ?>