<?php $__env->startSection('titulo', 'Pedido Produto'); ?>

<?php $__env->startSection('conteudo'); ?>
    
    <div class="conteudo-pagina">

        <div class="titulo-pagina-2">
            <p>Adicionar Produtos ao Pedido</p>
        </div>

        <div class="menu">
            <ul>
                <li><a href="<?php echo e(route('pedido.index')); ?>">Voltar</a></li>
                <li><a href="">Consulta</a></li>
            </ul>
        </div>

        <div class="informacao-pagina">
            <h4>Detalhes do pedido</h4>
            <p>ID do pedido: <?php echo e($pedido->id); ?></p>
            <p>Cliente: <?php echo e($pedido->cliente_id); ?></p> 
            
            <div style="width: 30%; margin-left: auto; margin-right: auto;">
                <h4>Itens do pedido</h4>
                <table border="1" width="100%">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome do produto</th>
                            <th>Data de inclusão do item no pedido</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pedido->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($produto->id); ?></td>
                                <td><?php echo e($produto->nome); ?></td>
                                <td><?php echo e($produto->pivot->created_at->format('d/m/Y')); ?></td>
                                <td>
                                    <form id="form_<?php echo e($produto->pivot->id); ?>" method="post" action="<?php echo e(route('pedido-produto.destroy', ['pedidoProduto' => $produto->pivot->id, 'pedido_id' => $pedido->id])); ?>">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <a href="#" onclick="document.getElementById('form_<?php echo e($produto->pivot->id); ?>').submit()">Excluir</a>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                </table>

                <?php $__env->startComponent('app.pedido_produto._components.form_create', ['pedido' => $pedido, 'produtos' => $produtos]); ?>
                <?php if (isset($__componentOriginalaa4f483eefda5c4dda991140498b4346af500776)): ?>
<?php $component = $__componentOriginalaa4f483eefda5c4dda991140498b4346af500776; ?>
<?php unset($__componentOriginalaa4f483eefda5c4dda991140498b4346af500776); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?> 
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app.layouts.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/app/pedido_produto/create.blade.php ENDPATH**/ ?>