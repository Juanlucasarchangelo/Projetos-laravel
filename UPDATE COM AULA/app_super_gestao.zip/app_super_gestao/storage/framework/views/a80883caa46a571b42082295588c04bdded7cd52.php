<?php $__env->startSection('titulo', 'Detalhes do Produto'); ?>

<?php $__env->startSection('conteudo'); ?>
    
    <div class="conteudo-pagina">

        <div class="titulo-pagina-2">
            <p>Editar Detalhes do Produto</p>
        </div>

        <div class="menu">
            <ul>
                <li><a href="#">Voltar</a></li>
            </ul>
        </div>

        <div class="informacao-pagina">
            <?php echo e($produto_detalhe->toJson()); ?>

            <h4>Produto</h4>
            <div>Nome: <?php echo e($produto_detalhe->item->nome); ?></div>
            <?php echo e($produto_detalhe->toJson()); ?>

            <br>
            <div>Descrição: <?php echo e($produto_detalhe->item->descricao); ?></div>
            <br>

            <div style="width: 30%; margin-left: auto; margin-right: auto;">
                <?php $__env->startComponent('app.produto_detalhe._components.form_create_edit', ['produto_detalhe' => $produto_detalhe, 'unidades' => $unidades]); ?>
                <?php if (isset($__componentOriginalfae04aadb88bdf16d70a4f5924eef1ca894fb7e7)): ?>
<?php $component = $__componentOriginalfae04aadb88bdf16d70a4f5924eef1ca894fb7e7; ?>
<?php unset($__componentOriginalfae04aadb88bdf16d70a4f5924eef1ca894fb7e7); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app.layouts.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/app/produto_detalhe/edit.blade.php ENDPATH**/ ?>