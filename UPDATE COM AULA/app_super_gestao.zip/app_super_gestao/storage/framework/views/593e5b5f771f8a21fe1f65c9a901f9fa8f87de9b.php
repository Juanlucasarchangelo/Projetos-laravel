<?php if(isset($pedido->id)): ?>
    <form method="post" action="<?php echo e(route('pedido.update', ['pedido' => $pedido->id])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
<?php else: ?>
    <form method="post" action="<?php echo e(route('pedido.store')); ?>">
        <?php echo csrf_field(); ?>
<?php endif; ?>

    <select name="cliente_id">
        <option>-- Selecione um Cliente --</option>

        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($cliente->id); ?>" <?php echo e(($pedido->cliente_id ?? old('cliente_id')) == $cliente->id ? 'selected' : ''); ?> ><?php echo e($cliente->nome); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php echo e($errors->has('cliente_id') ? $errors->first('cliente_id') : ''); ?>


    <button type="submit" class="borda-preta">Cadastrar</button>
<form><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/app/pedido/_components/form_create_edit.blade.php ENDPATH**/ ?>