<?php if(isset($produto_detalhe->id)): ?>
    <form method="post" action="<?php echo e(route('produto-detalhe.update', ['produto_detalhe' => $produto_detalhe->id])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
<?php else: ?>
    <form method="post" action="<?php echo e(route('produto-detalhe.store')); ?>">
        <?php echo csrf_field(); ?>
<?php endif; ?>
    <input type="text" name="produto_id" value="<?php echo e($produto_detalhe->produto_id ?? old('produto_id')); ?>" placeholder="ID do Produto" class="borda-preta">
    <?php echo e($errors->has('produto_id') ? $errors->first('produto_id') : ''); ?>


    <input type="text" name="comprimento" value="<?php echo e($produto_detalhe->comprimento ?? old('comprimento')); ?>" placeholder="Comprimento" class="borda-preta">
    <?php echo e($errors->has('comprimento') ? $errors->first('comprimento') : ''); ?>


    <input type="text" name="largura" value="<?php echo e($produto_detalhe->largura ?? old('largura')); ?>"  placeholder="Largura" class="borda-preta">
    <?php echo e($errors->has('largura') ? $errors->first('largura') : ''); ?>


    <input type="text" name="altura" value="<?php echo e($produto_detalhe->altura ?? old('altura')); ?>"  placeholder="Altura" class="borda-preta">
    <?php echo e($errors->has('altura') ? $errors->first('altura') : ''); ?>


    <select name="unidade_id">
        <option>-- Selecione a Unidade de Medida --</option>

        <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($unidade->id); ?>" <?php echo e(($produto_detalhe->unidade_id ?? old('unidade_id')) == $unidade->id ? 'selected' : ''); ?> ><?php echo e($unidade->descricao); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php echo e($errors->has('unidade_id') ? $errors->first('unidade_id') : ''); ?>

    
    <button type="submit" class="borda-preta">Cadastrar</button>
<form><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/app/produto_detalhe/_components/form_create_edit.blade.php ENDPATH**/ ?>