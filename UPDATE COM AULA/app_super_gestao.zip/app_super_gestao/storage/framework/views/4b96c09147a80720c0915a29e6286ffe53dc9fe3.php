<?php $__env->startSection('titulo', 'Fornecedor'); ?>

<?php $__env->startSection('conteudo'); ?>
    
    <div class="conteudo-pagina">

        <div class="titulo-pagina-2">
            <p>Fornecedor - Listar</p>
        </div>

        <div class="menu">
            <ul>
                <li><a href="<?php echo e(route('app.fornecedor.adicionar')); ?>">Novo</a></li>
                <li><a href="<?php echo e(route('app.fornecedor')); ?>">Consulta</a></li>
            </ul>
        </div>

        <div class="informacao-pagina">
            <div style="width: 90%; margin-left: auto; margin-right: auto;">
                <table border="1" width="100%">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Site</th>
                            <th>UF</th>
                            <th>E-mail</th>
                            <th></th>
                            <th></th>
                        </tr>
                    </head>

                    <tbody>
                        <?php $__currentLoopData = $fornecedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fornecedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($fornecedor->nome); ?></td>
                                <td><?php echo e($fornecedor->site); ?></td>
                                <td><?php echo e($fornecedor->uf); ?></td>
                                <td><?php echo e($fornecedor->email); ?></td>
                                <td><a href="<?php echo e(route('app.fornecedor.excluir', $fornecedor->id)); ?>">Excluir</a></td>
                                <td><a href="<?php echo e(route('app.fornecedor.editar', $fornecedor->id)); ?>">Editar</a></td>
                            </tr>
                            <tr>
                                <td colspan="6">
                                    <p>Lista de produtos</p>
                                    <table border="1" style="margin:20px">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Nome</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $fornecedor->produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($produto->id); ?></td>
                                                    <td><?php echo e($produto->nome); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </td>
                            <tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                
                <?php echo e($fornecedores->appends($request)->links()); ?>


                <!--
                <br>
                <?php echo e($fornecedores->count()); ?> - Total de registros por página
                <br>
                <?php echo e($fornecedores->total()); ?> - Total de registros da consulta
                <br>
                <?php echo e($fornecedores->firstItem()); ?> - Número do primeiro registro da página
                <br>
                <?php echo e($fornecedores->lastItem()); ?> - Número do último registro da página

                -->
                <br>
                Exibindo <?php echo e($fornecedores->count()); ?> fornecedores de <?php echo e($fornecedores->total()); ?> (de <?php echo e($fornecedores->firstItem()); ?> a <?php echo e($fornecedores->lastItem()); ?>)
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('app.layouts.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/app/fornecedor/listar.blade.php ENDPATH**/ ?>