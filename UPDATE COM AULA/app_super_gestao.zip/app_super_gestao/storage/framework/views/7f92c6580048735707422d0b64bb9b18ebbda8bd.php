<?php if(isset($produto->id)): ?>
    <form method="post" action="<?php echo e(route('produto.update', ['produto' => $produto->id])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
<?php else: ?>
    <form method="post" action="<?php echo e(route('produto.store')); ?>">
        <?php echo csrf_field(); ?>
<?php endif; ?>

    <select name="fornecedor_id">
        <option>-- Selecione um Fornecedor --</option>

        <?php $__currentLoopData = $fornecedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fornecedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($fornecedor->id); ?>" <?php echo e(($produto->fornecedor_id ?? old('fornecedor_id')) == $fornecedor->id ? 'selected' : ''); ?> ><?php echo e($fornecedor->nome); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php echo e($errors->has('fornecedor_id') ? $errors->first('fornecedor_id') : ''); ?>


    <input type="text" name="nome" value="<?php echo e($produto->nome ?? old('nome')); ?>" placeholder="Nome" class="borda-preta">
    <?php echo e($errors->has('nome') ? $errors->first('nome') : ''); ?>


    <input type="text" name="descricao" value="<?php echo e($produto->descricao ?? old('descricao')); ?>" placeholder="Descrição" class="borda-preta">
    <?php echo e($errors->has('descricao') ? $errors->first('descricao') : ''); ?>


    <input type="text" name="peso" value="<?php echo e($produto->peso ?? old('peso')); ?>"  placeholder="peso" class="borda-preta">
    <?php echo e($errors->has('peso') ? $errors->first('peso') : ''); ?>


    <select name="unidade_id">
        <option>-- Selecione a Unidade de Medida --</option>

        <?php $__currentLoopData = $unidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($unidade->id); ?>" <?php echo e(($produto->unidade_id ?? old('unidade_id')) == $unidade->id ? 'selected' : ''); ?> ><?php echo e($unidade->descricao); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php echo e($errors->has('unidade_id') ? $errors->first('unidade_id') : ''); ?>

    
    <button type="submit" class="borda-preta">Cadastrar</button>
<form><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/app/produto/_components/form_create_edit.blade.php ENDPATH**/ ?>