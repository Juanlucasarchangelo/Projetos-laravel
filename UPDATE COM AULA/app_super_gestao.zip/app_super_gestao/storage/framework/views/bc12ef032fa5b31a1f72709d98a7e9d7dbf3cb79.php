<?php if(isset($cliente->id)): ?>
    <form method="post" action="<?php echo e(route('cliente.update', ['cliente' => $cliente->id])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
<?php else: ?>
    <form method="post" action="<?php echo e(route('cliente.store')); ?>">
        <?php echo csrf_field(); ?>
<?php endif; ?>

    <input type="text" name="nome" value="<?php echo e($cliente->nome ?? old('nome')); ?>" placeholder="Nome" class="borda-preta">
    <?php echo e($errors->has('nome') ? $errors->first('nome') : ''); ?>


    <button type="submit" class="borda-preta">Cadastrar</button>
<form><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/app/cliente/_components/form_create_edit.blade.php ENDPATH**/ ?>