<?php $__env->startSection('titulo', 'Cliente'); ?>

<?php $__env->startSection('conteudo'); ?>
    <br><br><br><br>Cliente
<?php $__env->stopSection(); ?>


<?php echo $__env->make('app.layouts.basico', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/jorge/Documents/Code/app_super_gestao/resources/views/app/cliente.blade.php ENDPATH**/ ?>